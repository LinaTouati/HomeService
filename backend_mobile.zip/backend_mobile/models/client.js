const pool = require("../config/db");
const bcrypt = require("bcrypt");
require("dotenv").config();

exports.register = async (req, res) => {
    console.log("🔵 Requête reçue sur /auth/register");
    console.log("📦 Données reçues:", req.body);

    try {
        const { nom, prenom, numero_telephone, email, date_naissance, adresse, mot_de_passe } = req.body;

        // 🔍 Vérification de l'email en base
        console.log("🔍 Vérification de l'email existant...");
        const existingUser = await pool.query("SELECT * FROM client WHERE email = $1", [email]);

        if (existingUser.rows.length > 0) {
            console.log("❌ Email déjà utilisé:", email);
            return res.status(409).json({ error: "Cet email est déjà utilisé." });
        }

        // 🔐 Hachage du mot de passe
        console.log("🔐 Hachage du mot de passe...");
        const hashedPassword = await bcrypt.hash(mot_de_passe, 10);

        // 📝 Insertion du client en base
        console.log("📝 Insertion du client en base...");
        const newUser = await pool.query(
            `INSERT INTO client (nom, prenom, numero_telephone, email, date_naissance, adresse, mot_de_passe)
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
            [nom, prenom, numero_telephone, email, date_naissance, adresse, hashedPassword]
        );

        console.log("✅ Client inséré avec succès:", newUser.rows[0]);

        return res.status(201).json({
            message: "Inscription réussie",
            user: newUser.rows[0]
        });

    } catch (error) {
        console.error("❌ Erreur lors de l'inscription:", error.message);
        return res.status(500).json({ error: "Erreur interne du serveur" });
    }
};
