const express = require("express");
const cors = require("cors");
const authRoutes = require("./routes/authRoutes"); // 🔵 Routes des clients
const prestataireRoutes = require("./routes/prestaroutes"); // ✅ Correspond au bon fichier
 // 🟠 Routes des prestataires
const dotenv = require("dotenv");

dotenv.config();

const PORT = 3000;
const HOST = "localhost"; // Écoute uniquement sur localhost

const app = express();

// 🛠️ Configuration CORS (Ouverture complète temporaire pour tests)
const corsOptions = {
  origin: "*",
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type"],
  credentials: true,
};

app.use(cors(corsOptions));
app.use(express.json()); // 🔥 Assurer le bon traitement des requêtes JSON

// 📌 Vérification du chargement des routes
console.log("🔄 AuthRoutes chargé...");
app.use("/auth", authRoutes); 

console.log("🔄 PrestataireRoutes chargé...");
app.use("/prestataire", prestataireRoutes); 

// 📡 Vérification du serveur
app.get("/", (req, res) => {
  res.status(200).json({ status: "OK", message: "API opérationnelle" });
});

// 🔍 Gestion des erreurs
app.use((err, req, res, next) => {
  console.error("🔥 Erreur serveur:", err.stack);
  res.status(500).json({
    error: "Erreur interne du serveur",
    details: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// 🚀 Lancer le serveur
app.listen(PORT, HOST, () => {
  console.log(`✅ Serveur opérationnel sur http://${HOST}:${PORT}`);
});
